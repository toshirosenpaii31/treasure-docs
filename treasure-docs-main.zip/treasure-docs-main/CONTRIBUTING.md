# Contributing
Any and all contributors to Treasure Docs are welcome. 

If you have any ideas or changes you'd like to make, please feel free to raise any [issues](https://github.com/treasure-tools/treasure-docs/issues) and submit [pull requests](https://github.com/treasure-tools/treasure-docs/pulls) in this repository on GitHub.

A Treasure Docs team member will then review, suggest any changes if needed, and merge your pull requests into Treasure Docs which will update the documentation.

If you have any questions, please don't hesitate to contact **0xkarel** on [Twitter](https://twitter.com/0xkarel).
